﻿(function () {

    Vue.component('page1-component', {
        template: '<h1>Page1</h1>',
    });


})();
