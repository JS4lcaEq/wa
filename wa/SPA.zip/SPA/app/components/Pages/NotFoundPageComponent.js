﻿(function () {

    Vue.component('notfound-page-component', {
        template: '<h1>Page not found</h1>',
    });


})();
